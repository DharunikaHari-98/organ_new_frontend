import React, { useState, useEffect } from 'react';
import http from '../services/http';

const OrganRequestDashboard = () => {
  const [requests, setRequests] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [organTypeFilter, setOrganTypeFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [sortBy, setSortBy] = useState('');

  useEffect(() => {
    (async () => {
      try {
        const res = await http.get('/api/organ-requests');
        setRequests(res.data || []);
        setFiltered(res.data || []);
      } catch (e) {
        setRequests([]);
        setFiltered([]);
      }
    })();
  }, []);

  useEffect(() => {
    let temp = [...requests];

    if (organTypeFilter) {
      temp = temp.filter((r) => r.organType === organTypeFilter); // use organType (camelCase)
    }
    if (statusFilter) {
      temp = temp.filter((r) => r.status === statusFilter);
    }
    if (sortBy === 'urgency') {
      const priority = { HIGH: 1, MEDIUM: 2, LOW: 3 };
      temp.sort((a, b) => (priority[a.urgency] || 99) - (priority[b.urgency] || 99));
    } else if (sortBy === 'date_asc') {
      temp.sort((a, b) => new Date(a.requestDate).getTime() - new Date(b.requestDate).getTime());
    }

    setFiltered(temp);
  }, [organTypeFilter, statusFilter, sortBy, requests]);

  return (
    <div>
      <h2>Organ Requests</h2>

      <select value={organTypeFilter} onChange={(e) => setOrganTypeFilter(e.target.value)}>
        <option value="">All Organ Types</option>
        <option value="KIDNEY">Kidney</option>
        <option value="LIVER">Liver</option>
        <option value="HEART">Heart</option>
        <option value="LUNG">Lung</option>
        <option value="PANCREAS">Pancreas</option>
        <option value="CORNEA">Cornea</option>
      </select>

      <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
        <option value="">All Status</option>
        <option value="PENDING">PENDING</option>
        <option value="FULFILLED">FULFILLED</option>
        <option value="CANCELLED">CANCELLED</option>
      </select>

      <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
        <option value="">Sort</option>
        <option value="urgency">Urgency</option>
        <option value="date_asc">Date Ascending</option>
      </select>

      <table>
        <thead>
          <tr>
            <th>Hospital</th>
            <th>Organ Type</th>
            <th>Patient</th>
            <th>Urgency</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((req) => (
            <tr key={req.id}>
              <td>{req.hospitalName}</td>
              <td>{req.organType}</td>
              <td>{req.patientName}</td>
              <td>{req.urgency}</td>
              <td>{req.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrganRequestDashboard;
