"use client"

import React, { useState } from "react"
const styles = {
  container: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    background: "linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)",
    padding: "1rem",
    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
  },
  wrapper: {
    width: "100%",
    maxWidth: "28rem",
    display: "flex",
    flexDirection: "column",
    gap: "2rem",
  },
  header: {
    textAlign: "center",
    display: "flex",
    flexDirection: "column",
    gap: "0.5rem",
  },
  title: {
    fontSize: "1.875rem",
    fontWeight: "700",
    color: "#1f2937",
    margin: "0",
    fontFamily: "Work Sans, serif",
  },
  subtitle: {
    color: "#6b7280",
    margin: "0",
  },
  card: {
    backgroundColor: "#ffffff",
    borderRadius: "0.75rem",
    border: "1px solid #e5e7eb",
    boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
    overflow: "hidden",
  },
  cardHeader: {
    padding: "1.5rem 1.5rem 0 1.5rem",
    textAlign: "center",
    display: "flex",
    flexDirection: "column",
    gap: "0.25rem",
  },
  cardTitle: {
    fontSize: "1.5rem",
    fontWeight: "600",
    color: "#1f2937",
    margin: "0",
  },
  cardDescription: {
    color: "#6b7280",
    fontSize: "0.875rem",
    margin: "0",
  },
  cardContent: {
    padding: "1.5rem",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "1rem",
  },
  fieldGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "0.5rem",
  },
  label: {
    fontSize: "0.875rem",
    fontWeight: "500",
    color: "#374151",
  },
  input: {
    height: "2.75rem",
    padding: "0 0.75rem",
    border: "1px solid #d1d5db",
    borderRadius: "0.5rem",
    fontSize: "0.875rem",
    transition: "all 0.2s",
    outline: "none",
    backgroundColor: "#ffffff",
  },
  inputFocus: {
    borderColor: "#8b5cf6",
    boxShadow: "0 0 0 3px rgba(139, 92, 246, 0.1)",
  },
  passwordContainer: {
    position: "relative",
  },
  passwordToggle: {
    position: "absolute",
    right: "0.75rem",
    top: "50%",
    transform: "translateY(-50%)",
    background: "none",
    border: "none",
    color: "#6b7280",
    cursor: "pointer",
    padding: "0.25rem",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  rememberRow: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  checkboxGroup: {
    display: "flex",
    alignItems: "center",
    gap: "0.5rem",
  },
  checkbox: {
    width: "1rem",
    height: "1rem",
    accentColor: "#8b5cf6",
  },
  checkboxLabel: {
    fontSize: "0.875rem",
    color: "#6b7280",
  },
  forgotLink: {
    fontSize: "0.875rem",
    color: "#8b5cf6",
    textDecoration: "none",
    transition: "color 0.2s",
  },
  button: {
    width: "100%",
    height: "2.75rem",
    backgroundColor: "#1f2937",
    color: "#ffffff",
    border: "none",
    borderRadius: "0.5rem",
    fontSize: "0.875rem",
    fontWeight: "500",
    cursor: "pointer",
    transition: "all 0.2s",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "0.5rem",
  },
  buttonHover: {
    backgroundColor: "#374151",
    boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
  },
  buttonDisabled: {
    opacity: "0.6",
    cursor: "not-allowed",
  },
  signupText: {
    marginTop: "1.5rem",
    textAlign: "center",
    fontSize: "0.875rem",
    color: "#6b7280",
  },
  signupLink: {
    color: "#8b5cf6",
    textDecoration: "none",
    fontWeight: "500",
    transition: "color 0.2s",
  },
  footer: {
    textAlign: "center",
    fontSize: "0.75rem",
    color: "#9ca3af",
  },
  alert: {
    padding: "0.75rem",
    backgroundColor: "#fef2f2",
    border: "1px solid #fecaca",
    borderRadius: "0.5rem",
    color: "#dc2626",
    fontSize: "0.875rem",
  },
  spinner: {
    width: "1rem",
    height: "1rem",
    border: "2px solid transparent",
    borderTop: "2px solid currentColor",
    borderRadius: "50%",
    animation: "spin 1s linear infinite",
  },
}

const spinnerCSS = `
  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }
`

const EyeIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
)

const EyeOffIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
    <line x1="1" y1="1" x2="23" y2="23" />
  </svg>
)

const Spinner = () => <div style={styles.spinner}></div>

export default function LoginPage({ onLogin }) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [focusedInput, setFocusedInput] = useState("")

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      if (onLogin) {
        await onLogin({ username, password })
      } else {
        await new Promise((resolve) => setTimeout(resolve, 1000))
        console.log("Login attempted with:", { username, password })
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred.")
    } finally {
      setIsLoading(false)
    }
  }
  React.useEffect(() => {
    const styleElement = document.createElement("style")
    styleElement.textContent = spinnerCSS
    document.head.appendChild(styleElement)
    return () => document.head.removeChild(styleElement)
  }, [])

  return (
    <div style={styles.container}>
      <div style={styles.wrapper}>
        {/* Header */}
        <div style={styles.header}>
          <h1 style={styles.title}>Welcome Back</h1>
          <p style={styles.subtitle}>Sign in to your account to continue</p>
        </div>
        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h2 style={styles.cardTitle}>Sign In</h2>
            <p style={styles.cardDescription}>Enter your credentials to access your account</p>
          </div>
          <div style={styles.cardContent}>
            <form onSubmit={handleSubmit} style={styles.form}>
              {error && <div style={styles.alert}>{error}</div>}

              <div style={styles.fieldGroup}>
                <label htmlFor="username" style={styles.label}>
                  Username or Email
                </label>
                <input
                  id="username"
                  type="text"
                  placeholder="Enter your username or email"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  onFocus={() => setFocusedInput("username")}
                  onBlur={() => setFocusedInput("")}
                  required
                  style={{
                    ...styles.input,
                    ...(focusedInput === "username" ? styles.inputFocus : {}),
                  }}
                  disabled={isLoading}
                />
              </div>

              <div style={styles.fieldGroup}>
                <label htmlFor="password" style={styles.label}>
                  Password
                </label>
                <div style={styles.passwordContainer}>
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onFocus={() => setFocusedInput("password")}
                    onBlur={() => setFocusedInput("")}
                    required
                    style={{
                      ...styles.input,
                      paddingRight: "2.5rem",
                      ...(focusedInput === "password" ? styles.inputFocus : {}),
                    }}
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    style={styles.passwordToggle}
                    disabled={isLoading}
                  >
                    {showPassword ? <EyeOffIcon /> : <EyeIcon />}
                  </button>
                </div>
              </div>

              <div style={styles.rememberRow}>
                <div style={styles.checkboxGroup}>
                  <input id="remember" type="checkbox" style={styles.checkbox} />
                  <label htmlFor="remember" style={styles.checkboxLabel}>
                    Remember me
                  </label>
                </div>
                <a href="/forgot-password" style={styles.forgotLink}>
                  Forgot password?
                </a>
              </div>

              <button
                type="submit"
                style={{
                  ...styles.button,
                  ...(isLoading ? styles.buttonDisabled : {}),
                }}
                disabled={isLoading}
                onMouseEnter={(e) => {
                  if (!isLoading) {
                    Object.assign(e.target.style, styles.buttonHover)
                  }
                }}
                onMouseLeave={(e) => {
                  Object.assign(e.target.style, styles.button)
                }}
              >
                {isLoading ? (
                  <>
                    <Spinner />
                    Signing in...
                  </>
                ) : (
                  "Sign In"
                )}
              </button>
            </form>

            <div style={styles.signupText}>
              <p>
                Don't have an account?{" "}
                <a href="/register" style={styles.signupLink}>
                  Sign up now
                </a>
              </p>
            </div>
          </div>
        </div>
        <div style={styles.footer}>
          <p>© 2024 Vitalink. All rights reserved.</p>
        </div>
      </div>
    </div>
  )
}
