const API_BASE = 'http://localhost:8080/api';

/**
 * A central handler for all API requests.
 * It provides consistent error handling, JSON parsing, and logging.
 * @param {Promise<Response>} requestPromise A fetch() call.
 * @returns {Promise<any>} The JSON response from the server.
 */
const apiHandler = async (requestPromise) => {
    try {
        const response = await requestPromise;

        if (!response.ok) {
            let errorMessage = `Request failed with status: ${response.status}`;
            try {
                const errorBody = await response.json();
                errorMessage = errorBody.message || JSON.stringify(errorBody);
            } catch (e) {
            }
            console.error("API Error:", errorMessage);
            throw new Error(errorMessage);
        }

        const contentType = response.headers.get("content-type");
        if (contentType && contentType.indexOf("application/json") !== -1) {
            return response.json(); // If there's a JSON body, parse and return it
        }
        return null;

    } catch (error) {
        console.error("A network or API error occurred:", error.message);
        throw error;
    }
};

export const getOrganRequests = ({ page, pageSize }) => {
    const params = new URLSearchParams({ page, size: pageSize });
    return apiHandler(fetch(`${API_BASE}/organ-requests?${params.toString()}`));
};
export const getOrganRequestById = (id) => {
    return apiHandler(fetch(`${API_BASE}/organ-requests/${id}`));
};
export const createOrganRequest = (data) => {
    return apiHandler(fetch(`${API_BASE}/organ-requests`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    }));
};

export const getBloodRequests = ({ page, pageSize }) => {
    const params = new URLSearchParams({ page, size: pageSize });
    return apiHandler(fetch(`${API_BASE}/blood-requests?${params.toString()}`));
};
export const getBloodRequestById = (id) => {
    return apiHandler(fetch(`${API_BASE}/blood-requests/${id}`));
};
export const createBloodRequest = (data) => {
    return apiHandler(fetch(`${API_BASE}/blood-requests`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    }));
};

export const findOrganMatches = (id) => {
    return apiHandler(fetch(`${API_BASE}/organ-requests/${id}/match`, { method: 'POST' }));
};
export const getOrganRequestCandidates = (id) => {
    return apiHandler(fetch(`${API_BASE}/organ-requests/${id}/candidates`));
};
export const findBloodMatches = (id) => {
    return apiHandler(fetch(`${API_BASE}/blood-requests/${id}/match`, { method: 'POST' }));
};
export const getBloodRequestCandidates = (id) => {
    return apiHandler(fetch(`${API_BASE}/blood-requests/${id}/candidates`));
};
export const acceptMatch = (matchId) => {
    return apiHandler(fetch(`${API_BASE}/matches/${matchId}/accept`, { method: 'POST' }));
};
export const declineMatch = (matchId) => {
    return apiHandler(fetch(`${API_BASE}/matches/${matchId}/decline`, { method: 'POST' }));
};

export const getAllocations = ({ page, pageSize, status }) => {
    const params = new URLSearchParams({ page, size: pageSize });
    if (status) params.append('status', status);
    return apiHandler(fetch(`${API_BASE}/allocations?${params.toString()}`));
};
export const createAllocation = (data) => {
    return apiHandler(fetch(`${API_BASE}/allocations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    }));
};
export const updateAllocation = ({ id, updateData }) => {
    return apiHandler(fetch(`${API_BASE}/allocations/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updateData),
    }));
};
export const getAllocationEvents = (id) => {
    return apiHandler(fetch(`${API_BASE}/allocations/${id}/events`));
};
export const addAllocationEvent = ({ id, eventData }) => {
    return apiHandler(fetch(`${API_BASE}/allocations/${id}/events`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventData),
    }));
};

export const getSummaryReport = () => {
    return apiHandler(fetch(`${API_BASE}/reports/summary`));
};
export const getTurnaroundReport = ({ from, to }) => {
    const params = new URLSearchParams({ from, to });
    return apiHandler(fetch(`${API_BASE}/reports/turnaround?${params.toString()}`));
};
export const getAuditLogs = ({ entityType, entityId }) => {
    const params = new URLSearchParams({ entityType, entityId });
    return apiHandler(fetch(`${API_BASE}/audit?${params.toString()}`));
};

export const createNotification = (data) => {
    return apiHandler(fetch(`${API_BASE}/notifications`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    }));
};