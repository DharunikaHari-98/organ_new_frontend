import React, { useState } from 'react';
import {
  AppBar, Box, CssBaseline, Drawer, List, ListItem, ListItemButton,
  ListItemIcon, ListItemText, Toolbar, Typography, Button, Avatar,
  IconButton, Badge, Tooltip, Divider, Chip, useTheme, alpha
} from '@mui/material';
import { useNavigate, Outlet, useLocation } from 'react-router-dom';
import { styled, keyframes } from '@mui/material/styles';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PeopleIcon from '@mui/icons-material/People';
import MedicalServicesIcon from '@mui/icons-material/MedicalServices';
import BloodtypeIcon from '@mui/icons-material/Bloodtype';
import AssignmentTurnedInIcon from "@mui/icons-material/AssignmentTurnedIn";
import AssessmentIcon from '@mui/icons-material/Assessment';
import PolicyIcon from '@mui/icons-material/Policy';
import NotificationsIcon from '@mui/icons-material/Notifications';
import SettingsIcon from '@mui/icons-material/Settings';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import { useAuth } from '../../../context/AuthContext';

const drawerWidth = 280;
const collapsedDrawerWidth = 80;

// Stunning animations
const shimmer = keyframes`
  0% { background-position: -200px 0; }
  100% { background-position: calc(200px + 100%) 0; }
`;

const float = keyframes`
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-6px); }
`;

const glow = keyframes`
  0%, 100% { box-shadow: 0 0 20px rgba(33, 150, 243, 0.3); }
  50% { box-shadow: 0 0 30px rgba(33, 150, 243, 0.6); }
`;

const slideIn = keyframes`
  from { transform: translateX(-100%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
`;

// Glassmorphism AppBar
const GlassAppBar = styled(AppBar)(({ theme, collapsed }) => ({
  background: `linear-gradient(135deg,
    ${alpha(theme.palette.primary.main, 0.9)} 0%,
    ${alpha(theme.palette.secondary.main, 0.8)} 100%)`,
  backdropFilter: 'blur(20px)',
  borderBottom: `1px solid ${alpha(theme.palette.common.white, 0.1)}`,
  boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
  width: `calc(100% - ${collapsed ? collapsedDrawerWidth : drawerWidth}px)`,
  marginLeft: collapsed ? collapsedDrawerWidth : drawerWidth,
  transition: theme.transitions.create(['width', 'margin'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '100%',
    background: `linear-gradient(90deg, transparent, ${alpha(theme.palette.common.white, 0.1)}, transparent)`,
    animation: `${shimmer} 3s infinite linear`,
  }
}));

// Premium Sidebar
const StyledDrawer = styled(Drawer)(({ theme, collapsed }) => ({
  width: collapsed ? collapsedDrawerWidth : drawerWidth,
  flexShrink: 0,
  whiteSpace: 'nowrap',
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  '& .MuiDrawer-paper': {
    width: collapsed ? collapsedDrawerWidth : drawerWidth,
    background: `linear-gradient(180deg,
      ${theme.palette.background.paper} 0%,
      ${alpha(theme.palette.primary.main, 0.05)} 100%)`,
    backdropFilter: 'blur(10px)',
    borderRight: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`,
    boxShadow: '4px 0 24px rgba(0, 0, 0, 0.1)',
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    overflow: 'hidden',
  }
}));

// Animated Menu Item
const AnimatedListItemButton = styled(ListItemButton)(({ theme, active }) => ({
  margin: '8px 16px',
  borderRadius: '16px',
  padding: '12px 16px',
  position: 'relative',
  overflow: 'hidden',
  background: active
    ? `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.15)}, ${alpha(theme.palette.secondary.main, 0.1)})`
    : 'transparent',
  border: active ? `1px solid ${alpha(theme.palette.primary.main, 0.2)}` : '1px solid transparent',
  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  animation: active ? `${glow} 2s infinite` : 'none',

  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: '-100%',
    width: '100%',
    height: '100%',
    background: `linear-gradient(90deg, transparent, ${alpha(theme.palette.primary.main, 0.1)}, transparent)`,
    transition: 'left 0.5s',
  },

  '&:hover': {
    background: `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.1)}, ${alpha(theme.palette.secondary.main, 0.05)})`,
    transform: 'translateY(-2px) scale(1.02)',
    boxShadow: `0 8px 25px ${alpha(theme.palette.primary.main, 0.3)}`,

    '&::before': {
      left: '100%',
    },

    '& .MuiListItemIcon-root': {
      animation: `${float} 1s ease-in-out infinite`,
      color: theme.palette.primary.main,
    }
  },

  '& .MuiListItemIcon-root': {
    minWidth: '40px',
    color: active ? theme.palette.primary.main : theme.palette.text.secondary,
    transition: 'all 0.3s ease',
  },

  '& .MuiListItemText-root': {
    '& .MuiListItemText-primary': {
      fontWeight: active ? 600 : 400,
      color: active ? theme.palette.primary.main : theme.palette.text.primary,
      fontSize: '0.9rem',
    }
  }
}));

// Floating Action Elements
const NotificationBadge = styled(Badge)(({ theme }) => ({
  '& .MuiBadge-badge': {
    background: `linear-gradient(45deg, ${theme.palette.error.main}, ${theme.palette.warning.main})`,
    animation: `${float} 2s ease-in-out infinite`,
    boxShadow: `0 0 10px ${alpha(theme.palette.error.main, 0.5)}`,
  }
}));

const UserAvatar = styled(Avatar)(({ theme }) => ({
  background: `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
  boxShadow: `0 4px 20px ${alpha(theme.palette.primary.main, 0.4)}`,
  transition: 'all 0.3s ease',
  cursor: 'pointer',

  '&:hover': {
    transform: 'scale(1.1)',
    boxShadow: `0 6px 25px ${alpha(theme.palette.primary.main, 0.6)}`,
  }
}));

const LogoSection = styled(Box)(({ theme, collapsed }) => ({
  padding: collapsed ? '20px 12px' : '20px 24px',
  background: `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.1)}, ${alpha(theme.palette.secondary.main, 0.05)})`,
  borderBottom: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`,
  display: 'flex',
  alignItems: 'center',
  justifyContent: collapsed ? 'center' : 'flex-start',
  transition: 'all 0.3s ease',
}));

const AdminLayout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const { user, logout } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [notifications] = useState(5); // Mock notification count

  const menuItems = [
    { text: 'Dashboard', icon: <DashboardIcon />, path: '/admin', badge: null },
    { text: 'Manage Donors', icon: <PeopleIcon />, path: '/admin/donors', badge: '24' },
    { text: 'Organ Requests', icon: <MedicalServicesIcon />, path: '/admin/organ-requests', badge: '3' },
    { text: 'Blood Requests', icon: <BloodtypeIcon />, path: '/admin/blood-requests', badge: '7' },
    { text: 'Allocations', icon: <AssignmentTurnedInIcon />, path: '/admin/allocations', badge: null },
    { text: 'Reports', icon: <AssessmentIcon />, path: '/admin/reports/summary', badge: null },
    { text: 'Audit Viewer', icon: <PolicyIcon />, path: '/admin/audit', badge: null },
  ];

  const toggleDrawer = () => {
    setCollapsed(!collapsed);
  };

  const isPathActive = (path) => {
    return location.pathname === path || (path !== '/admin' && location.pathname.startsWith(path));
  };

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <CssBaseline />

      {/* Premium AppBar */}
      <GlassAppBar position="fixed" collapsed={collapsed}>
        <Toolbar sx={{ px: 3 }}>
          <IconButton
            edge="start"
            color="inherit"
            onClick={toggleDrawer}
            sx={{
              mr: 2,
              transition: 'all 0.3s ease',
              '&:hover': {
                transform: 'rotate(180deg)',
                backgroundColor: alpha(theme.palette.common.white, 0.1)
              }
            }}
          >
            {collapsed ? <MenuIcon /> : <ChevronLeftIcon />}
          </IconButton>

          <Typography
            variant="h5"
            component="div"
            sx={{
              flexGrow: 1,
              fontWeight: 700,
              background: `linear-gradient(45deg, ${theme.palette.common.white}, ${alpha(theme.palette.secondary.light, 0.8)})`,
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              color: 'transparent',
              textShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}
          >
            Healthcare Admin
          </Typography>

          {/* Action Icons */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Tooltip title="Notifications" arrow>
              <IconButton color="inherit">
                <NotificationBadge badgeContent={notifications} color="error">
                  <NotificationsIcon />
                </NotificationBadge>
              </IconButton>
            </Tooltip>

            <Tooltip title="Settings" arrow>
              <IconButton color="inherit">
                <SettingsIcon />
              </IconButton>
            </Tooltip>

            <Tooltip title={`Welcome, ${user?.username}`} arrow>
              <UserAvatar sx={{ width: 40, height: 40, mx: 1 }}>
                {user?.username?.charAt(0).toUpperCase()}
              </UserAvatar>
            </Tooltip>

            <Button
              color="inherit"
              onClick={logout}
              variant="outlined"
              sx={{
                borderColor: alpha(theme.palette.common.white, 0.3),
                '&:hover': {
                  borderColor: theme.palette.common.white,
                  backgroundColor: alpha(theme.palette.common.white, 0.1),
                  transform: 'translateY(-2px)',
                }
              }}
            >
              Logout
            </Button>
          </Box>
        </Toolbar>
      </GlassAppBar>

      {/* Enhanced Sidebar */}
      <StyledDrawer variant="permanent" anchor="left" collapsed={collapsed}>
        <LogoSection collapsed={collapsed}>
          {!collapsed && (
            <Box sx={{ animation: `${slideIn} 0.3s ease-out` }}>
              <Typography
                variant="h6"
                sx={{
                  fontWeight: 800,
                  background: `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                  backgroundClip: 'text',
                  WebkitBackgroundClip: 'text',
                  color: 'transparent',
                }}
              >
                HealthCare+
              </Typography>
              <Typography variant="caption" color="text.secondary">
                Admin Dashboard
              </Typography>
            </Box>
          )}
          {collapsed && (
            <Box
              sx={{
                width: 40,
                height: 40,
                borderRadius: '12px',
                background: `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontWeight: 'bold',
                fontSize: '1.2rem'
              }}
            >
              H+
            </Box>
          )}
        </LogoSection>

        <Divider sx={{ opacity: 0.1 }} />

        <List sx={{ py: 2 }}>
          {menuItems.map((item, index) => (
            <ListItem key={item.text} disablePadding>
              <AnimatedListItemButton
                active={isPathActive(item.path)}
                onClick={() => navigate(item.path)}
                sx={{
                  animationDelay: `${index * 0.1}s`,
                  justifyContent: collapsed ? 'center' : 'initial',
                }}
              >
                <Tooltip title={collapsed ? item.text : ''} placement="right" arrow>
                  <ListItemIcon sx={{ minWidth: collapsed ? 'unset' : '40px' }}>
                    {item.badge ? (
                      <Badge
                        badgeContent={item.badge}
                        color="error"
                        variant="dot"
                        sx={{
                          '& .MuiBadge-badge': {
                            animation: `${float} 2s ease-in-out infinite`,
                          }
                        }}
                      >
                        {item.icon}
                      </Badge>
                    ) : (
                      item.icon
                    )}
                  </ListItemIcon>
                </Tooltip>
                {!collapsed && (
                  <ListItemText
                    primary={item.text}
                    sx={{
                      opacity: collapsed ? 0 : 1,
                      transition: 'opacity 0.3s ease'
                    }}
                  />
                )}
                {!collapsed && item.badge && (
                  <Chip
                    label={item.badge}
                    size="small"
                    color="error"
                    sx={{
                      height: '20px',
                      fontSize: '0.75rem',
                      animation: `${float} 2s ease-in-out infinite`,
                    }}
                  />
                )}
              </AnimatedListItemButton>
            </ListItem>
          ))}
        </List>
      </StyledDrawer>

      {/* Main Content Area */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          background: `linear-gradient(135deg,
            ${alpha(theme.palette.background.default, 0.95)} 0%,
            ${alpha(theme.palette.primary.light, 0.02)} 100%)`,
          minHeight: '100vh',
          p: 3,
          transition: theme.transitions.create('margin', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen,
          }),
          position: 'relative',

          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: `radial-gradient(circle at 20% 80%, ${alpha(theme.palette.primary.main, 0.05)} 0%, transparent 50%),
                        radial-gradient(circle at 80% 20%, ${alpha(theme.palette.secondary.main, 0.05)} 0%, transparent 50%)`,
            pointerEvents: 'none',
            zIndex: 0,
          }
        }}
      >
        <Toolbar />
        <Box sx={{ position: 'relative', zIndex: 1 }}>
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
};

export default AdminLayout;