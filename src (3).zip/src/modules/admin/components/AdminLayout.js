import React from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  Container,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Badge,
  Divider,
  IconButton,
} from '@mui/material';

import DashboardIcon from '@mui/icons-material/Dashboard';
import PeopleIcon from '@mui/icons-material/People';
import MedicalServicesIcon from '@mui/icons-material/MedicalServices';
import BloodtypeIcon from '@mui/icons-material/Bloodtype';
import AssignmentTurnedInIcon from '@mui/icons-material/AssignmentTurnedIn';
import AssessmentIcon from '@mui/icons-material/Assessment';
import PolicyIcon from '@mui/icons-material/Policy';
import SettingsIcon from '@mui/icons-material/Settings';
import NotificationsIcon from '@mui/icons-material/Notifications';

import { useQuery } from '@tanstack/react-query';
import { getSummaryReport } from '../services/adminApi';

const drawerWidth = 260;

const AdminLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Dynamic counts for sidebar badges
  const { data } = useQuery({
    queryKey: ['summaryReport'],
    queryFn: getSummaryReport,
    refetchInterval: 10000,              // refresh every 10s
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
    refetchOnMount: 'always',
    staleTime: 0,
  });

  const donorsTotal = data?.donors?.total ?? 0;
  const organOpen = data?.organRequests?.OPEN ?? 0;
  const bloodOpen = data?.bloodRequests?.OPEN ?? 0;

  const menuItems = [
    { text: 'Dashboard',        icon: <DashboardIcon />,        path: '/admin',                    badge: null },
    { text: 'Manage Donors',    icon: <PeopleIcon />,           path: '/admin/donors',             badge: donorsTotal || null },
    { text: 'Organ Requests',   icon: <MedicalServicesIcon />,  path: '/admin/organ-requests',     badge: organOpen || null },
    { text: 'Blood Requests',   icon: <BloodtypeIcon />,        path: '/admin/blood-requests',     badge: bloodOpen || null },
    { text: 'Allocations',      icon: <AssignmentTurnedInIcon />, path: '/admin/allocations',      badge: null },
    { text: 'Reports',          icon: <AssessmentIcon />,       path: '/admin/reports/summary',    badge: null },
    { text: 'Audit Viewer',     icon: <PolicyIcon />,           path: '/admin/audit',              badge: null },
  ];

  const NavItem = ({ item }) => {
    const selected =
      location.pathname === item.path || location.pathname.startsWith(item.path + '/');

    return (
      <ListItem disablePadding>
        <ListItemButton
          component={Link}
          to={item.path}
          selected={selected}
          sx={{ borderRadius: 1.5, mx: 1, my: 0.5 }}
        >
          <ListItemIcon sx={{ minWidth: 40 }}>{item.icon}</ListItemIcon>
          <ListItemText primary={item.text} />
          {item.badge ? (
            <Badge color="error" badgeContent={item.badge} sx={{ '& .MuiBadge-badge': { right: -2 } }} />
          ) : null}
        </ListItemButton>
      </ListItem>
    );
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {/* Top Navbar (unchanged UI) */}
      <AppBar
        position="static"
        sx={{
          background: 'linear-gradient(90deg, #6a11cb 0%, #2575fc 100%)',
          boxShadow: '0 6px 14px rgba(0,0,0,0.15)',
        }}
      >
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1, fontWeight: 700 }}>
            Healthcare Admin
          </Typography>

          <IconButton color="inherit" size="large" sx={{ mr: 1 }}>
            <Badge color="error" variant="dot">
              <NotificationsIcon />
            </Badge>
          </IconButton>

          <IconButton color="inherit" size="large" sx={{ mr: 1 }}>
            <SettingsIcon />
          </IconButton>

          <Button
            color="inherit"
            variant="outlined"
            sx={{ color: 'white', borderColor: 'rgba(255,255,255,0.6)' }}
            onClick={() => navigate('/login')}
          >
            LOGOUT
          </Button>
        </Toolbar>
      </AppBar>

      <Box sx={{ display: 'flex', flex: 1 }}>
        {/* Sidebar (unchanged UI) */}
        <Drawer
          variant="permanent"
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: 'border-box', p: 1.5 },
          }}
        >
          <Toolbar />
          <Box sx={{ overflow: 'auto' }}>
            <List sx={{ px: 0.5 }}>
              {menuItems.map((item) => (
                <NavItem key={item.text} item={item} />
              ))}
            </List>
            <Divider sx={{ my: 1.5 }} />
          </Box>
        </Drawer>

        {/* Main content */}
        <Container maxWidth="lg" sx={{ flexGrow: 1, py: 3 }}>
          <Outlet />
        </Container>
      </Box>

      {/* Footer (unchanged UI) */}
      <Box
        component="footer"
        sx={{ py: 2, textAlign: 'center', bgcolor: 'grey.200', mt: 'auto' }}
      >
        <Typography variant="body2" color="text.secondary">
          © {new Date().getFullYear()} Organ Donation Management System
        </Typography>
      </Box>
    </Box>
  );
};

export default AdminLayout;
