import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getBloodRequestById,
  getBloodRequestCandidates,
  matchBloodRequest,
} from '../services/adminApi';

import {
  Box, Paper, Grid, Typography, Button, Chip, CircularProgress
} from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';

const columns = [
  { field: 'id', headerName: 'Match ID', width: 100,
    renderCell: (p) => <span>#{p.value}</span>
  },
  { field: 'matchScore', headerName: 'Compatibility Score', width: 180,
    renderCell: (p) => <span>{p.value} %</span>
  },
  { field: 'status', headerName: 'Status', width: 220,
    renderCell: (p) => (
      <Chip
        label={p.value?.replaceAll('_', ' ')}
        color={p.value?.includes('PENDING') ? 'warning' : 'success'}
        variant="outlined"
      />
    )
  },
  { field: 'donorProfileId', headerName: 'Donor ID', width: 120,
    renderCell: (p) => <span>#{p.value}</span>
  },
];

export default function BloodRequestDetailPage() {
  const { id } = useParams();
  const requestId = Number(id);
  const qc = useQueryClient();

  const { data: request, isLoading: reqLoading } = useQuery({
    queryKey: ['bloodRequest', requestId],
    queryFn: () => getBloodRequestById(requestId),
  });

  const { data: candidates = [], isLoading: candLoading } = useQuery({
    queryKey: ['bloodCandidates', requestId],
    queryFn: () => getBloodRequestCandidates(requestId),
  });

  const matchMutation = useMutation({
    mutationFn: () => matchBloodRequest(requestId),
    onSuccess: (list) => {
      // Update table immediately with the returned candidates
      qc.setQueryData(['bloodCandidates', requestId], list);
      // Refresh the request to reflect status change OPEN->MATCHED
      qc.invalidateQueries({ queryKey: ['bloodRequest', requestId] });
    },
  });

  if (reqLoading) return <Box p={4}><CircularProgress /></Box>;

  return (
    <Box>
      <Grid container spacing={3}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>Request Details</Typography>
            <Box sx={{ mt: 1 }}>
              <Typography><b>Hospital</b><br />{request.hospitalName}</Typography>
              <Typography sx={{ mt: 2 }}><b>Status</b><br />{request.status}</Typography>
              <Typography sx={{ mt: 2 }}><b>Blood Group</b><br />{request.bloodGroup}</Typography>
              <Typography sx={{ mt: 2 }}><b>Quantity</b><br />{request.quantityUnits} units</Typography>
            </Box>

            <Button
              fullWidth
              sx={{ mt: 3 }}
              variant="contained"
              disabled={matchMutation.isLoading}
              onClick={() => matchMutation.mutate()}
            >
              {matchMutation.isLoading ? 'Finding…' : 'FIND MATCHES'}
            </Button>
          </Paper>
        </Grid>

        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 2, height: 520 }}>
            <Typography variant="h6" gutterBottom>Match Candidates</Typography>
            <div style={{ height: 440 }}>
              <DataGrid
                rows={candidates ?? []}
                columns={columns}
                loading={candLoading || matchMutation.isLoading}
                getRowId={(row) => row.id}
                disableRowSelectionOnClick
              />
            </div>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
