// src/modules/admin/services/adminApi.js

const API_BASE = 'http://localhost:8080/api';

/** Uniform fetch handler (shared by all calls) */
export const apiHandler = async (requestPromise) => {
  try {
    const res = await requestPromise;

    if (!res.ok) {
      let msg = `Request failed with status: ${res.status}`;
      try {
        const body = await res.json();
        msg = body.message || JSON.stringify(body);
      } catch (_) {}
      throw new Error(msg);
    }

    if (res.status === 204) return null;

    const ct = res.headers.get('content-type') || '';
    if (ct.includes('application/json')) return await res.json();
    return await res.text();
  } catch (err) {
    console.error('[adminApi]', err);
    throw err;
  }
};

/* ===================== BLOOD REQUESTS ===================== */

export const getBloodRequests = ({ page = 0, pageSize = 10 } = {}) => {
  const params = new URLSearchParams({ page, size: pageSize });
  return apiHandler(fetch(`${API_BASE}/blood-requests?${params.toString()}`));
};
export const fetchBloodRequests = getBloodRequests; // alias

export const getBloodRequestById = (id) =>
  apiHandler(fetch(`${API_BASE}/blood-requests/${id}`));
export const fetchBloodRequestById = getBloodRequestById; // alias

export const createBloodRequest = (data) =>
  apiHandler(
    fetch(`${API_BASE}/blood-requests`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    })
  );

export const getBloodRequestCandidates = (id) =>
  apiHandler(fetch(`${API_BASE}/blood-requests/${id}/candidates`));
export const fetchBloodCandidates = getBloodRequestCandidates; // alias

export const matchBloodRequest = (id) =>
  apiHandler(fetch(`${API_BASE}/blood-requests/${id}/match`, { method: 'POST' }));
export const findBloodMatches = matchBloodRequest; // alias

/* ===================== ORGAN REQUESTS ===================== */

export const getOrganRequests = ({ page = 0, pageSize = 10 } = {}) => {
  const params = new URLSearchParams({ page, size: pageSize });
  return apiHandler(fetch(`${API_BASE}/organ-requests?${params.toString()}`));
};
export const fetchOrganRequests = getOrganRequests; // alias

export const getOrganRequestById = (id) =>
  apiHandler(fetch(`${API_BASE}/organ-requests/${id}`));
export const fetchOrganRequestById = getOrganRequestById; // alias

export const createOrganRequest = (data) =>
  apiHandler(
    fetch(`${API_BASE}/organ-requests`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    })
  );

export const getOrganRequestCandidates = (id) =>
  apiHandler(fetch(`${API_BASE}/organ-requests/${id}/candidates`));
export const fetchOrganCandidates = getOrganRequestCandidates; // alias

export const matchOrganRequest = (id) =>
  apiHandler(fetch(`${API_BASE}/organ-requests/${id}/match`, { method: 'POST' }));
export const findOrganMatches = matchOrganRequest; // alias

/* ===================== MATCH DECISIONS (COMMON) ===================== */

export const acceptMatch = (matchId) =>
  apiHandler(fetch(`${API_BASE}/matches/${matchId}/accept`, { method: 'POST' }));

export const declineMatch = (matchId) =>
  apiHandler(fetch(`${API_BASE}/matches/${matchId}/decline`, { method: 'POST' }));

/* ===================== ALLOCATIONS ===================== */

export const createAllocation = (data) =>
  apiHandler(
    fetch(`${API_BASE}/allocations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    })
  );

export const getAllocations = ({ status, page = 0, pageSize = 10 } = {}) => {
  const params = new URLSearchParams({ page, size: pageSize });
  if (status) params.set('status', status);
  return apiHandler(fetch(`${API_BASE}/allocations?${params.toString()}`));
};

export const getAllocationEvents = (allocationId) =>
  apiHandler(fetch(`${API_BASE}/allocations/${allocationId}/events`));

/* ===================== REPORTS & AUDIT ===================== */

export const getSummaryReport = () =>
  apiHandler(fetch(`${API_BASE}/reports/summary`));

export const getTurnaroundReport = () =>
  apiHandler(fetch(`${API_BASE}/reports/turnaround`));

export const getAuditLogs = ({ entityType, entityId }) => {
  const params = new URLSearchParams({ entityType, entityId });
  return apiHandler(fetch(`${API_BASE}/audit?${params.toString()}`));
};

/* ===================== NOTIFICATIONS ===================== */

export const createNotification = (data) =>
  apiHandler(
    fetch(`${API_BASE}/notifications`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    })
  );

export const getDonorProfileById = (id) =>
  apiHandler(fetch(`${API_BASE}/donor-profiles/${id}`));