// e.g., src/modules/donor/pages/DonorHome.js
import DonorAssistantBot from '../components/DonorAssistantBot';

export default function DonorHome() {
  return (
    <>
      {/* your donor page content */}
      <DonorAssistantBot />
    </>
  );
}
