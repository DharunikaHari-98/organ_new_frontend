// src/services/authApi.js

const API_ROOT = process.env.REACT_APP_API_URL || 'http://localhost:8080';
const API_BASE_URL = `${API_ROOT}/api/jwt-auth`;

/**
 * Register a new account (username/password/role).
 * Returns: { accessToken }
 */
export const registerUser = async ({ username, password, role }) => {
  const res = await fetch(`${API_BASE_URL}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, role })
  });

  if (!res.ok) {
    let msg = 'Registration failed';
    try { const j = await res.json(); msg = j?.error || j?.message || msg; } catch {}
    throw new Error(msg);
  }

  return res.json(); // { accessToken }
};

/**
 * Login with username/password.
 * Returns: { accessToken }
 */
export const loginUser = async ({ username, password }) => {
  const res = await fetch(`${API_BASE_URL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });

  if (!res.ok) {
    let msg = 'Invalid credentials';
    try { const j = await res.json(); msg = j?.error || j?.message || msg; } catch {}
    throw new Error(msg);
  }

  return res.json(); // { accessToken }
};
