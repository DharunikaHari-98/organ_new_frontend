// src/services/http.js
import axios from 'axios';

const baseURL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

const http = axios.create({ baseURL });

// Attach JWT and normalize query params
http.interceptors.request.use((config) => {
  // Attach token
  const token = localStorage.getItem('accessToken');
  if (token) config.headers.Authorization = `Bearer ${token}`;

  // Normalize params: if a value is an object, prefer .id/.code, else JSON-stringify
  if (config.params && typeof config.params === 'object') {
    const norm = {};
    for (const [k, v] of Object.entries(config.params)) {
      if (v == null || v === '') continue;
      if (typeof v === 'object') {
        if ('id' in v) norm[k] = v.id;
        else if ('code' in v) norm[k] = v.code;
        else norm[k] = JSON.stringify(v);
      } else {
        norm[k] = v;
      }
    }
    config.params = norm;
  }

  return config;
});

// Global auth error handling
http.interceptors.response.use(
  (res) => res,
  (err) => {
    const status = err?.response?.status;
    if (status === 401) {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('authUser');
      // Optionally redirect: window.location.assign('/login');
    } else if (status === 403) {
      // eslint-disable-next-line no-console
      console.warn('Forbidden: missing required role to access this resource.');
    }
    return Promise.reject(err);
  }
);

export default http;
