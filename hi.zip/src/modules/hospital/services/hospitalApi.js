// src/modules/hospital/services/hospitalApi.js
// Hospital API via the shared axios instance (adds Authorization automatically)
import http from '../../../services/http';

/* --------------------------------
   Donor lookup (list + by id)
--------------------------------- */
export const getDonorProfiles = ({ page = 0, pageSize = 10 } = {}) =>
  http.get('/api/donor-profiles', { params: { page, size: pageSize } }).then(r => r.data);

export const getDonorProfileById = (id) =>
  http.get(`/api/donor-profiles/${id}`).then(r => r.data);

// Aliases expected by some components
export const getDonors = getDonorProfiles;
export const getDonorById = getDonorProfileById;

/* --------------------------------
   Organ Requests (CRUD-ish + match)
--------------------------------- */
export const getOrganRequests = ({ page = 0, pageSize = 10, status, city, state } = {}) =>
  http.get('/api/organ-requests', { params: { page, size: pageSize, status, city, state } }).then(r => r.data);

export const getOrganRequestById = (id) =>
  http.get(`/api/organ-requests/${id}`).then(r => r.data);

export const createOrganRequest = (payload) =>
  http.post('/api/organ-requests', payload).then(r => r.data);

export const findOrganMatches = (id) =>
  http.post(`/api/organ-requests/${id}/match`).then(r => r.data);

export const getOrganRequestCandidates = (id) =>
  http.get(`/api/organ-requests/${id}/candidates`).then(r => r.data);

/* --------------------------------
   Blood Requests (CRUD-ish + match)
--------------------------------- */
export const getBloodRequests = ({ page = 0, pageSize = 10, status, city, state } = {}) =>
  http.get('/api/blood-requests', { params: { page, size: pageSize, status, city, state } }).then(r => r.data);

export const getBloodRequestById = (id) =>
  http.get(`/api/blood-requests/${id}`).then(r => r.data);

export const createBloodRequest = (payload) =>
  http.post('/api/blood-requests', payload).then(r => r.data);

export const findBloodMatches = (id) =>
  http.post(`/api/blood-requests/${id}/match`).then(r => r.data);

export const getBloodRequestCandidates = (id) =>
  http.get(`/api/blood-requests/${id}/candidates`).then(r => r.data);

/* --------------------------------
   Matches (accept / decline)
--------------------------------- */
export const acceptMatch = (matchId) =>
  http.post(`/api/matches/${matchId}/accept`).then(r => r.data);

export const declineMatch = (matchId) =>
  http.post(`/api/matches/${matchId}/decline`).then(r => r.data);

/* --------------------------------
   Allocations
--------------------------------- */
export const getAllocations = ({ page = 0, pageSize = 10, status } = {}) =>
  http.get('/api/allocations', { params: { page, size: pageSize, status } }).then(r => r.data);

export const getAllocationById = (id) =>
  http.get(`/api/allocations/${id}`).then(r => r.data);

export const getAllocationEvents = (id) =>
  http.get(`/api/allocations/${id}/events`).then(r => r.data);

export const createAllocation = (data) =>
  http.post('/api/allocations', data).then(r => r.data);

/* --------------------------------
   Reports & Audit
--------------------------------- */
export const getSummaryReport = (args = {}) =>
  http.get('/api/reports/summary', { params: args }).then(r => r.data);

export const getAuditLogs = ({ entityType, entityId } = {}) =>
  http.get('/api/audit', { params: { entityType, entityId } }).then(r => r.data);
