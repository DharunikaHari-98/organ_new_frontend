// src/modules/admin/services/adminApi.js
// Central Admin API via axios instance that auto-attaches JWT

import http from '../../../services/http';

// ---- Matches (accept / decline) ----
export const acceptMatch = (matchId) =>
  http.post(`/api/matches/${matchId}/accept`).then(r => r.data);

export const declineMatch = (matchId) =>
  http.post(`/api/matches/${matchId}/decline`).then(r => r.data);

// ---- Allocations ----
export const getAllocations = ({ page = 0, pageSize = 10, status } = {}) =>
  http.get('/api/allocations', { params: { page, size: pageSize, status } }).then(r => r.data);

export const getAllocationById = (id) =>
  http.get(`/api/allocations/${id}`).then(r => r.data);

export const getAllocationEvents = (id) =>
  http.get(`/api/allocations/${id}/events`).then(r => r.data);

export const createAllocation = (data) =>
  http.post('/api/allocations', data).then(r => r.data);

export const updateAllocation = (id, data) =>
  http.put(`/api/allocations/${id}`, data).then(r => r.data);

// ---- Blood Requests ----
export const getBloodRequests = ({ page = 0, pageSize = 10, status, city, state } = {}) =>
  http.get('/api/blood-requests', { params: { page, size: pageSize, status, city, state } }).then(r => r.data);

export const fetchBloodRequestById = (id) =>
  http.get(`/api/blood-requests/${id}`).then(r => r.data);

export const createBloodRequest = (payload) =>
  http.post('/api/blood-requests', payload).then(r => r.data);

export const findBloodMatches = (id) =>
  http.post(`/api/blood-requests/${id}/match`).then(r => r.data);

export const fetchBloodCandidates = (id) =>
  http.get(`/api/blood-requests/${id}/candidates`).then(r => r.data);

// ---- Organ Requests ----
export const getOrganRequests = ({ page = 0, pageSize = 10, status, city, state } = {}) =>
  http.get('/api/organ-requests', { params: { page, size: pageSize, status, city, state } }).then(r => r.data);

export const getOrganRequestById = (id) =>
  http.get(`/api/organ-requests/${id}`).then(r => r.data);

export const createOrganRequest = (payload) =>
  http.post('/api/organ-requests', payload).then(r => r.data);

export const findOrganMatches = (id) =>
  http.post(`/api/organ-requests/${id}/match`).then(r => r.data);

export const getOrganRequestCandidates = (id) =>
  http.get(`/api/organ-requests/${id}/candidates`).then(r => r.data);

// ---- Donors / Profiles (admin views) ----
export const getDonorProfileById = (id) =>
  http.get(`/api/donors/${id}`).then(r => r.data);

// ---- Reports ----
// helper to ensure clean query strings
const normalizeReportArgs = (args = {}) => {
  const out = { ...args };
  if (out.client && typeof out.client === 'object') {
    out.client = out.client.id ?? out.client.code ?? String(out.client);
  }
  if (out.dateRange && typeof out.dateRange === 'object') {
    out.from ??= out.dateRange.from;
    out.to   ??= out.dateRange.to;
    delete out.dateRange;
  }
  Object.keys(out).forEach(k => (out[k] == null || out[k] === '') && delete out[k]);
  return out;
};

export const getSummaryReport = (args = {}) =>
  http.get('/api/reports/summary', { params: normalizeReportArgs(args) }).then(r => r.data);

export const getTurnaroundReport = (args = {}) =>
  http.get('/api/reports/turnaround', { params: normalizeReportArgs(args) }).then(r => r.data);

// ---- Audit logs ----
export const getAuditLogs = ({ entityType, entityId } = {}) =>
  http.get('/api/audit', { params: { entityType, entityId } }).then(r => r.data);
