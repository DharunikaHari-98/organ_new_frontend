// src/services/donorAdminApi.js
import http from '../../../services/http';

export const getDonors = ({ page = 0, pageSize = 10 } = {}) =>
  http.get('/api/donor-profiles', { params: { page, size: pageSize } }).then(r => r.data);

export const getDonorById = (id) =>
  http.get(`/api/donor-profiles/${id}`).then(r => r.data);

export const createDonor = (donorData) =>
  http.post('/api/donor-profiles', donorData).then(r => r.data);

export const updateDonor = ({ id, ...donorData }) =>
  http.put(`/api/donor-profiles/${id}`, donorData).then(r => r.data);
