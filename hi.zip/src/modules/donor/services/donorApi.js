// src/services/donorSelfApi.js
import http from '../../../services/http';

// --- Donor profile (self) ---
export const getMyProfile = async (id) => {
  try {
    const { data } = await http.get(`/api/donor-profiles/${id}`);
    return data;
  } catch (e) {
    if (e?.response?.status === 400 || e?.response?.status === 404) return null;
    throw e;
  }
};

export const createMyProfile = (donorData) =>
  http.post('/api/donor-profiles', donorData).then(r => r.data);

export const updateMyProfile = ({ id, donorData }) =>
  http.put(`/api/donor-profiles/${id}`, donorData).then(r => r.data);

// --- Consents ---
export const getMyConsents = (donorProfileId) =>
  http.get('/api/consent-records', { params: { donorProfileId } }).then(r => r.data);

export const createConsent = (consentData) =>
  http.post('/api/consent-records', consentData).then(r => r.data);

// --- Matches ---
export const getMyMatches = (donorProfileId) =>
  http.get('/api/matches', { params: { donorProfileId } }).then(r => r.data);

export const acceptMatch = (matchId) =>
  http.post(`/api/matches/${matchId}/accept`).then(r => r.data);

export const declineMatch = (matchId) =>
  http.post(`/api/matches/${matchId}/decline`).then(r => r.data);

// --- Allocations (for donor) ---
export const getAllocations = ({ page = 0, pageSize = 100 } = {}) =>
  http.get('/api/allocations', { params: { page, size: pageSize } }).then(r => r.data);

export const getAllocationEvents = (id) =>
  http.get(`/api/allocations/${id}/events`).then(r => r.data);
