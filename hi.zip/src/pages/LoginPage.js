// src/pages/LoginPage.js
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import {
  Container, TextField, Button, Box, Typography, Alert,
  Grid, CircularProgress, Fade
} from '@mui/material';
import { styled } from '@mui/material/styles';

const StyledRoot = styled('div')({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  minHeight: '100vh',
  position: 'relative',
  background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
  '&::before': {
    content: '""', position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    backgroundImage: 'url(https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=2070&auto=format&fit=crop)',
    backgroundSize: 'cover', backgroundPosition: 'center',
    filter: 'blur(3px)', opacity: 0.3, zIndex: -1,
  },
  '&::after': {
    content: '""', position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    background: 'linear-gradient(135deg, rgba(245,247,250,0.8), rgba(195,207,226,0.9))',
    zIndex: -1,
  }
});

const FormContainer = styled(Box)(({ theme }) => ({
  padding: theme.spacing(5, 4),
  background: 'rgba(255,255,255,0.95)',
  backdropFilter: 'blur(10px)',
  borderRadius: theme.shape.borderRadius * 3,
  boxShadow: '0 8px 32px rgba(0,0,0,0.1)',
  border: '1px solid rgba(255,255,255,0.3)',
  color: '#333',
  maxWidth: 450,
  width: '100%',
}));

function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      await login({ username, password }, navigate);
    } catch (err) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <StyledRoot>
      <Container component="main" maxWidth="xs">
        <Fade in timeout={800}>
          <FormContainer>
            <Typography component="h1" variant="h4" sx={{ mb: 3, fontWeight: 600, textAlign: 'center' }}>
              Sign In
            </Typography>
            <Box component="form" onSubmit={handleSubmit}>
              {error && <Alert severity="error" variant="filled" sx={{ width: '100%', mb: 2, borderRadius: 2 }}>{error}</Alert>}
              <TextField
                margin="normal" required fullWidth label="Username" name="username" autoFocus
                value={username} onChange={(e) => setUsername(e.target.value)} variant="filled"
              />
              <TextField
                margin="normal" required fullWidth name="password" label="Password" type="password"
                value={password} onChange={(e) => setPassword(e.target.value)} variant="filled"
              />
              <Button type="submit" fullWidth variant="contained" disabled={isLoading} sx={{ mt: 3, mb: 2, py: 1.5 }}>
                {isLoading ? <CircularProgress size={26} color="inherit" /> : 'Sign In'}
              </Button>
              <Grid container>
                <Grid item>
                  <Link to="/register" style={{ textDecoration: 'none' }}>
                    <Typography variant="body2" sx={{ color: '#667eea', fontWeight: 500 }}>
                      New to Vitalink? Sign up now.
                    </Typography>
                  </Link>
                </Grid>
              </Grid>
            </Box>
          </FormContainer>
        </Fade>
      </Container>
    </StyledRoot>
  );
}

export default LoginPage;
