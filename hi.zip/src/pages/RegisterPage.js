// src/pages/RegisterPage.js
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { registerUser } from '../services/authApi';
import http from '../services/http';
import {
  Container,
  TextField,
  Button,
  Box,
  Typography,
  Alert,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Paper,
  Avatar,
  Grid,
  CircularProgress,
  Fade,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import PersonAddOutlinedIcon from '@mui/icons-material/PersonAddOutlined';

const StyledRoot = styled('div')(({ theme }) => ({
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  minHeight: '100vh',
  padding: theme.spacing(2, 0),
  background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 40%, #e0c3fc 100%)',
  position: 'relative',
  '&::before': {
    content: '""',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background:
      'radial-gradient(circle at 30% 20%, rgba(102, 126, 234, 0.1) 0%, transparent 70%), radial-gradient(circle at 70% 80%, rgba(240, 147, 251, 0.1) 0%, transparent 70%)',
    zIndex: 1,
  },
}));

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  borderRadius: theme.shape.borderRadius * 3,
  background: 'rgba(255, 255, 255, 0.9)',
  backdropFilter: 'blur(15px)',
  boxShadow: '0 12px 40px rgba(0, 0, 0, 0.1)',
  border: '1px solid rgba(255, 255, 255, 0.3)',
  position: 'relative',
  zIndex: 2,
}));

const StyledAvatar = styled(Avatar)(({ theme }) => ({
  width: 56,
  height: 56,
  background: 'linear-gradient(45deg, #667eea, #764ba2)',
  boxShadow: '0 4px 15px rgba(102, 126, 234, 0.3)',
  margin: theme.spacing(1),
}));

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    fullName: '',
    email: '',
    role: 'DONOR',
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      // 1) Create the login account using JWT registration
      const { accessToken } = await registerUser({
        username: formData.username.trim(),
        password: formData.password,
        role: formData.role, // MUST be one of: DONOR, HOSPITAL, ORGAN_BANK, ADMIN
      });

      // 2) Store token so subsequent calls are authorized
      localStorage.setItem('accessToken', accessToken);

      // 3) If DONOR, also create donor profile (this uses http with Authorization header)
      if (formData.role === 'DONOR') {
        const donorPayload = {
          name: formData.fullName.trim(),
          email: formData.email.trim(),
          phone: '',
          dob: '1990-01-01',
          gender: 'OTHER',
          bloodGroup: 'A+',
          address: '',
          city: 'Chennai',
          state: 'TN',
          medicalNotes: '',
          willingPosthumous: true,
          willingBlood: true,
        };
        await http.post('/api/donor-profiles', donorPayload);
      }

      // 4) Go to login
      navigate('/login');
    } catch (err) {
      setError(err.message || 'Failed to register. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <StyledRoot>
      <Container component="main" maxWidth="xs">
        <Fade in timeout={800}>
          <StyledPaper>
            <StyledAvatar>
              <PersonAddOutlinedIcon />
            </StyledAvatar>
            <Typography component="h1" variant="h5" sx={{ fontWeight: 600 }}>
              Create Account
            </Typography>

            <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
              {error && (
                <Alert severity="error" sx={{ width: '100%', mb: 2, borderRadius: 2 }}>
                  {error}
                </Alert>
              )}

              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    label="Full Name"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    variant="filled"
                  />
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    label="Email Address"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    variant="filled"
                  />
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    label="Username"
                    name="username"
                    value={formData.username}
                    onChange={handleChange}
                    variant="filled"
                  />
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    label="Password"
                    name="password"
                    type="password"
                    value={formData.password}
                    onChange={handleChange}
                    variant="filled"
                  />
                </Grid>

                <Grid item xs={12}>
                  <FormControl fullWidth required variant="filled">
                    <InputLabel id="role-select-label">I am registering as a...</InputLabel>
                    <Select
                      labelId="role-select-label"
                      name="role"
                      value={formData.role}
                      label="I am registering as a..."
                      onChange={handleChange}
                    >
                      {/* Values must match backend enum exactly */}
                      <MenuItem value="DONOR">Donor</MenuItem>
                      <MenuItem value="HOSPITAL">Hospital Representative</MenuItem>
                      <MenuItem value="ORGAN_BANK">Organ Bank Staff</MenuItem>
                      <MenuItem value="ADMIN">System Admin</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>

              <Button
                type="submit"
                fullWidth
                variant="contained"
                disabled={isLoading}
                sx={{ mt: 3, mb: 2, py: 1.5 }}
              >
                {isLoading ? <CircularProgress size={24} color="inherit" /> : 'Sign Up'}
              </Button>

              <Grid container justifyContent="flex-end">
                <Grid item>
                  <Link to="/login" style={{ textDecoration: 'none' }}>
                    <Typography variant="body2" sx={{ color: '#667eea', fontWeight: 500 }}>
                      Already have an account? Sign In
                    </Typography>
                  </Link>
                </Grid>
              </Grid>
            </Box>
          </StyledPaper>
        </Fade>
      </Container>
    </StyledRoot>
  );
}
