import React from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

/**
 * Usage patterns supported:
 * 1) Wrapper with children:
 *    <ProtectedRoute allowedRoles={['ADMIN']}><AdminLayout /></ProtectedRoute>
 *
 * 2) As a route element with nested routes:
 *    <Route element={<ProtectedRoute allowedRoles={['ADMIN']} />}>
 *       <Route path="/admin" element={<AdminDashboard/>} />
 *    </Route>
 */
export default function ProtectedRoute({ allowedRoles, children }) {
  const { user, isAuthenticated, loading } = useAuth();
  const location = useLocation();

  // Show a tiny placeholder while AuthContext is fetching /api/auth/me
  if (loading) {
    return (
      <div style={{ padding: 16 }}>
        Loading…
      </div>
    );
  }

  // Not logged in → to login (preserve where they came from)
  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  // Role check (if provided)
  if (Array.isArray(allowedRoles) && allowedRoles.length > 0) {
    const ok = allowedRoles.includes(user?.role);
    if (!ok) return <Navigate to="/unauthorized" replace />;
  }

  // Support both children and nested <Outlet/>
  return children ?? <Outlet />;
}
