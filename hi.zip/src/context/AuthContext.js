// src/context/AuthContext.jsx

import React, { createContext, useState, useContext, useEffect } from 'react';
import http from '../services/http';
import { loginUser, registerUser } from '../services/authApi';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null); // { username, role, userId }
  const [loading, setLoading] = useState(true);

  // Boot: if token exists, fetch /api/auth/me to hydrate user
  useEffect(() => {
    (async () => {
      try {
        const token = localStorage.getItem('accessToken');
        if (!token) { setLoading(false); return; }
        const { data } = await http.get('/api/auth/me');
        setUser(data);
        localStorage.setItem('authUser', JSON.stringify(data));
      } catch {
        localStorage.removeItem('accessToken');
        localStorage.removeItem('authUser');
        setUser(null);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Login flow: get token, save, then fetch /me and redirect by role
  const login = async (credentials, navigate) => {
    const { accessToken } = await loginUser(credentials);
    localStorage.setItem('accessToken', accessToken);

    const { data } = await http.get('/api/auth/me'); // -> { username, role, userId }
    setUser(data);
    localStorage.setItem('authUser', JSON.stringify(data));

    switch (data.role) {
      case 'ADMIN': navigate('/admin'); break;
      case 'DONOR': navigate('/donor'); break;
      case 'HOSPITAL': navigate('/hospital'); break;
      case 'ORGAN_BANK': navigate('/organ-bank'); break;
      default: navigate('/');
    }
  };

  // Optional: expose register that also logs in immediately
  const register = async ({ username, password, role }, navigate) => {
    const { accessToken } = await registerUser({ username, password, role });
    localStorage.setItem('accessToken', accessToken);

    const { data } = await http.get('/api/auth/me');
    setUser(data);
    localStorage.setItem('authUser', JSON.stringify(data));

    switch (data.role) {
      case 'ADMIN': navigate('/admin'); break;
      case 'DONOR': navigate('/donor'); break;
      case 'HOSPITAL': navigate('/hospital'); break;
      case 'ORGAN_BANK': navigate('/organ-bank'); break;
      default: navigate('/');
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('authUser');
    localStorage.removeItem('accessToken');
    window.location.href = '/login';
  };

  const value = {
    user,
    loading,
    isAuthenticated: !!user,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (ctx === undefined) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
};
